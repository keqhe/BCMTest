#! bin/bash
ps aux | grep -ie pktgen.conf | awk '{print $2}' | xargs kill -9
ps aux | grep -ie pox.py | awk '{print $2}' | xargs kill -9
ps aux | grep -ie sniffer | awk '{print $2}' | xargs kill -9
#ps aux | grep -ie tcpdump | awk '{print $2}' | xargs kill -9
sleep 2
#./pox.py  samples.l2_test
#sudo bash ../pktgen/pktgen.conf.1-1-flow-dist.sh &
#tcpdump -w observe.pcap -i eth0 & #check packet stream
#sudo bash start_tcpdump.sh &
#./flow_mod_sniffer eth2.10 767 &
#./pox.py  samples.l2_modification_proactive_priority 
./pox.py samples.l2_burst_priority_p2
#./pox.py samples.l2_tablesize_priority
sleep 10

ps aux | grep -ie pktgen.conf | awk '{print $2}' | xargs kill -9
ps aux | grep -ie pox.py | awk '{print $2}' | xargs kill -9
ps aux | grep -ie sniffer | awk '{print $2}' | xargs kill -9
#export PATH=/usr/local/bro/bin:$PATH
#sudo bash parse_pcap.sh
python parse_control.py
