import os, sys, commands
import time

c = 1
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 1
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 1
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 1
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 1
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)


##############

c = 2
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 2
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 2
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)


c = 2
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)


c = 2
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)


############
c = 3
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 3
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 3
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 3
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 3
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

############
c = 4
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_128')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr128' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 4
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_128')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr128' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 4
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_128')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr128' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 4
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_128')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr128' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 4
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_128')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr128' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

############

c = 5
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_256')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr256' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 5
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_256')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr256' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 5
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_256')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr256' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 5
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_256')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr256' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 5
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_256')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr256' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

########
c= 6
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_512')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr512' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 6
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_512')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr512' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 6
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_512')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr512' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 6
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_512')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr512' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 6
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_512')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr512' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

###
c= 7
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_768')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr768' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 7
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_768')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr768' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 7
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_768')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr768' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 7
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_768')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr768' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 7
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_768')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr768' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

######
c= 8
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_1024')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr1024' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 8
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_1024')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr1024' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 8
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_1024')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr1024' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 8
i = 4
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_1024')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr1024' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 8
i = 5
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_1024')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr1024' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

