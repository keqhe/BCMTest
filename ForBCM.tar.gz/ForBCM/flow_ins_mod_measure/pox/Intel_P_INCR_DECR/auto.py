import os, sys, commands
import time

c = 1
i = 1
os.system('sudo bash measure_flow_mod_one_round_dist.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 1
i = 2
os.system('sudo bash measure_flow_mod_one_round_dist.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)

c = 1
i = 3
os.system('sudo bash measure_flow_mod_one_round_dist.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)

c = 1
i = 4
os.system('sudo bash measure_flow_mod_one_round_dist.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)

c = 1
i = 5
os.system('sudo bash measure_flow_mod_one_round_dist.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)


#####

c = 2
i = 1
os.system('sudo bash measure_flow_mod_one_round_dist_p2.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)

c = 2
i = 2
os.system('sudo bash measure_flow_mod_one_round_dist_p2.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)


c = 2
i = 3
os.system('sudo bash measure_flow_mod_one_round_dist_p2.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)

c = 2
i = 4
os.system('sudo bash measure_flow_mod_one_round_dist_p2.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)


c = 2
i = 5
os.system('sudo bash measure_flow_mod_one_round_dist_p2.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)


####


c = 3
i = 1
os.system('sudo bash measure_flow_mod_one_round_dist_p3.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i)) 
print 'have arest'
time.sleep(5)


c = 3
i = 2
os.system('sudo bash measure_flow_mod_one_round_dist_p3.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)

c = 3
i = 3
os.system('sudo bash measure_flow_mod_one_round_dist_p3.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 3
i = 4
os.system('sudo bash measure_flow_mod_one_round_dist_p3.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 3
i = 5
os.system('sudo bash measure_flow_mod_one_round_dist_p3.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


###

c = 4
i = 1
os.system('sudo bash measure_flow_mod_one_round_dist_p4.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)



c = 4
i = 2
os.system('sudo bash measure_flow_mod_one_round_dist_p4.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 4
i = 3
os.system('sudo bash measure_flow_mod_one_round_dist_p4.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 4
i = 4
os.system('sudo bash measure_flow_mod_one_round_dist_p4.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 4
i = 5
os.system('sudo bash measure_flow_mod_one_round_dist_p4.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)
