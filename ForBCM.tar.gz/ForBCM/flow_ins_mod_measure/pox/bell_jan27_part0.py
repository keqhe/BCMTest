import os, sys, commands
import time

############
c = 4
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(30)

c = 4
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(30)

c = 4
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_16')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr16' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(30)


############

c = 5
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 5
i = 2
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 5
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_32')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr32' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

#####################################
c= 5
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c= 5
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)


c= 5
i = 3
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_64')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr64' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)



