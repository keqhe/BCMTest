import os, sys, commands
import time

###
c= 7
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_768')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr768' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(60)

######
c= 8
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_1024')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr1024' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(20)


