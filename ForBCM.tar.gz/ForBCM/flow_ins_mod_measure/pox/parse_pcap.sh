#! bin/bash
#export PATH=/usr/local/bro/bin:$PATH
bro -r flow_mod_measure.pcap 
