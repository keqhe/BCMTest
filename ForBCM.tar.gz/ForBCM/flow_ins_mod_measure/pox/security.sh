sudo bash measure_auto.sh samples.l2_bell_burst & sudo bash  measure_auto2.sh samples.l2_bell_burst2  && fg
