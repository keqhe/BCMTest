4 priority 

P1 P2 P3 P4

Px means sends a busrt (100) pf rules with Px
