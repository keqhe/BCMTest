from __future__ import division
import os, sys, commands
import time

global start
start = {}
global end
end = {}
for line in open('my_packet_timestamp.txt'):
	line = line.strip()
		
	word = line.split()
	c = int(word[1]) + 1
	start[c] = (float(word[3]), float(word[5]))

for line in open('conn.log'):
	line = line[:-1]
	if line[0] != '#':
		word = line.split('\t')
		if word[2] == '10.0.0.1':
			if not (word[4] in end) or (float(word[0]) < end[word[4]]):
				end[word[4]] = float(word[0])
				print word[4], end[word[4]]
global num_delay
num_delay = {}
for key in start:
	if key in end:
		word = key.split('.')
		num = (int(word[2]) - 56 ) *256 + (int(word[3]) - 0)
		print num
		print end[key] - start[key]
		if end[key] - start[key] >= 0:
			num_delay[num] = (end[key] - start[key])*1000
		 
keys = num_delay.keys()
keys.sort()
w = open('result.txt','w')
total = 0.0
for key in keys:
	w.write('%d %f\n' % (key, num_delay[key]))
	total = total + num_delay[key]

w.close()
print 'total flow modification delay is:', total
print 'average flow mod delay is:', total/len(num_delay)
