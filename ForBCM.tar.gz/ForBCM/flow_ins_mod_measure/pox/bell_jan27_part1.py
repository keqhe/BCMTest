import os, sys, commands
import time

############
c = 4
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_128')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr128' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(20)


############

c = 5
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_256')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr256' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(20)



###########

c = 5
i = 1
os.system('sudo bash measure_auto.sh samples.bell_priority_incr_512')
os.system('cp sorted_flow_delay.txt Intel_INCR_DECR/incr512' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(20)




