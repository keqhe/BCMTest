import sys, os, time

print '%f' %time.time()
os.system('sudo bash ../pktgen/pktgen.conf.1-1-flow-dist.sh')
