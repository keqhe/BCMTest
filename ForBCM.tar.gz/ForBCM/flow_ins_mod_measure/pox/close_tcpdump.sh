#! bin/bash
#ps aux | grep -ie pktgen.conf | awk '{print $2}' | xargs kill -9
ps aux | grep -ie tcpdump | awk '{print $2}' | xargs kill -9
