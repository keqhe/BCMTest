gcc -o simplesniffer simplesniffer.c -lpcap
