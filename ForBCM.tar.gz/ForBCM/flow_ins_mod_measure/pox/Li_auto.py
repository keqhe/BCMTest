import os, sys, commands
import time

c = 1
i = 1
os.system('sudo bash measure_flow_mod_one_round_dist.sh')
os.system('cp sorted_flow_delay.txt BCM_Jan24_2/P' + str(c) + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)
