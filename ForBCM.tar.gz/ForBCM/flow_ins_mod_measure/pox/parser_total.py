from __future__ import division
import os, sys, commands
import time
for line in open('poxout'):
	line = line[:-1]
	if line[0] == 'D' and line[1] == 'A' and line[2] == 'T':
		word = line.split(' ')
		if word[1] == '10.0.0.1' and word[2] == '192.168.56.0':
			t_mod = float(word[3])

for line in open('conn.log'):
	line = line[:-1]
	if line[0] != '#':
		word = line.split('\t')
		if word[2] == '10.0.0.1' and word[4] == '192.168.59.255':
			t_out = float(word[0])
print 'start time:%f' %t_mod, 'end time:%f' %t_out
print 'modifying 1K flows costs (send flow mod as fast as possible):', (t_out - t_mod)*1000, 'ms'
print 'average delay is:', (t_out - t_mod) * 1000 /1024, 'ms'				
