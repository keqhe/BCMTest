#! bin/bash
tcpdump -w flow_mod_measure.pcap -i eth2 &
