import os, sys, commands
import time

c = 1
i = 1
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp1_1' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(10)

c = 1
i = 2
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp1_1' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)

c = 1
i = 3
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp1_1' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)



####### expr2
c = 2
i = 1
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_exp2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp2_1' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)

c = 2
i = 2
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_exp2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp2_1' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)

c = 2
i = 3
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_exp2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp2_1' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)



#####expr 1-2
c= 3
i = 1
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp1_2' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c= 3
i = 2
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp1_2' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c= 3
i = 3
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp1_2' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)




c = 4
i = 1
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_exp2_2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp2_2' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)


c = 4
i = 2
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_exp2_2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp2_2' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)

c = 4
i = 3
os.system('sudo bash measure_auto.sh samples.l2_burst_priority_further_exp2_2')
os.system('cp sorted_flow_delay.txt BCM_Li_experiments_size/Exp2_2' + '/sorted_flow_delay.txt' + str(i))
print 'have arest'
time.sleep(5)

