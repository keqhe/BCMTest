#! bin/bash
ps aux | grep -ie pktgen.conf | awk '{print $2}' | xargs kill -9
ps aux | grep -ie pox.py | awk '{print $2}' | xargs kill -9
ps aux | grep -ie tcpdump | awk '{print $2}' | xargs kill -9
sudo bash ../pktgen/pktgen.conf.1-1-flow-total.sh &
sleep 5
tcpdump -w observe.pcap -i eth0 & #check packet stream
./pox.py  samples.l2_modification_proactive_total > poxout &
sleep 120 # one round experiment should be finished in 30 min
ps aux | grep -ie pktgen.conf | awk '{print $2}' | xargs kill -9
ps aux | grep -ie pox.py | awk '{print $2}' | xargs kill -9
sudo bash parse_pcap.sh
python parser_total.py
